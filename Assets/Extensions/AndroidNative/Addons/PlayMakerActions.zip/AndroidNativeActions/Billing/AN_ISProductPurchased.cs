﻿using UnityEngine;
using UnionAssets.FLE;
using System.Collections;



namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Android Native - Billing")]
	public class AN_ISProductPurchased : FsmStateAction {

		public FsmString SKU;
		
		public FsmEvent successEvent;
		public FsmEvent failEvent;
		

		public override void OnEnter() {

			InitAndroidInventoryTask iTask = InitAndroidInventoryTask.Create();
			iTask.addEventListener(BaseEvent.COMPLETE, OnInvComplete);
			iTask.addEventListener(BaseEvent.FAILED, OnInvFailed);
			iTask.Run();
			

		}
		
		private void OnInvComplete(CEvent e) {
			e.dispatcher.removeEventListener(BaseEvent.COMPLETE, OnInvComplete);
			e.dispatcher.removeEventListener(BaseEvent.FAILED, OnInvFailed);
			
			if(AndroidInAppPurchaseManager.instance.inventory.IsProductPurchased(SKU.Value)) {
				Fsm.Event(successEvent);
			} else  {
				Fsm.Event(failEvent);
			}

			

			Finish();
			
		}
		
		private void OnInvFailed(CEvent e) {
			e.dispatcher.removeEventListener(BaseEvent.COMPLETE, OnInvComplete);
			e.dispatcher.removeEventListener(BaseEvent.FAILED, OnInvFailed);
			Fsm.Event(failEvent);
			Finish();
			
		}
		
		
		
	}
}
